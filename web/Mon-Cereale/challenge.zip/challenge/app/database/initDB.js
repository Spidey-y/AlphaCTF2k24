const { connectDB } = require('./database');
const { MongoClient } = require('mongodb');
const crypto = require('crypto');

const initializeDatabase = async () => {
  try {
    const db = await connectDB();
    const collection = db.collection('users');

    await collection.deleteMany({});

    const adminPassword = crypto.randomBytes(10).toString('hex');

    await collection.insertOne({
      username: 'admin',
      password: adminPassword,
      role: 'admin',
      age: 2,
      favouriteMeal: 'Cereals'
    });

    console.log('Admin user inserted successfully');
    console.log('Admin password:', adminPassword);
  } catch (err) {
    console.error('Database initialization error:', err);
  }
};

module.exports = { initializeDatabase };
